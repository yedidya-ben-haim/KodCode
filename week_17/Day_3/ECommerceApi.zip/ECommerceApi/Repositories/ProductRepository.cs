using ECommerceApi.Data;
using ECommerceApi.Model;
using Microsoft.EntityFrameworkCore;

namespace ECommerceApi.Repositories;

public class ProductRepository: IProductRepository
{
    private readonly ECommerceDbContext _context;

    public ProductRepository(ECommerceDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Product>> GetAllWithCategoryAsync()
    {
        return await _context.Products
            .Include(p => p.Category)
            .Include(p => p.Reviews)
            .ToListAsync();
    }

    public Task<IEnumerable<Category>> GetCategoriesWithFullTreeAsync()
    {
        throw new NotImplementedException();
    }

    public Task<IEnumerable<Product>> SearchAsync(string? searchTerm, int? categoryId, decimal? minPrice, decimal? maxPrice)
    {
        throw new NotImplementedException();
    }

    public Task<IEnumerable<Product>> GetSortedAsync(string? sortBy, bool descending)
    {
        throw new NotImplementedException();
    }

    public Task<IEnumerable<object>> GetProductRatingsAsync()
    {
        throw new NotImplementedException();
    }

    public Task<IEnumerable<object>> GetProductCountByCategoryAsync()
    {
        throw new NotImplementedException();
    }

    public Task<(IEnumerable<Product> Products, int TotalCount)> GetPagedAsync(int page, int pageSize)
    {
        throw new NotImplementedException();
    }
}